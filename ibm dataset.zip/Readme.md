To Run The File simply install python then install the libraries - 
numpy , pandas , matplotlib , seaborn , sci-kit-learn
then run EDA+MODEL.py from your shell
all the data analytics graphs will get displayed one by one

if you just wanted to see output simply open EDA+MODEL.ipynb file it is a jupyter notebook file
it contains the codes and their outputs in a better way i would suggest to go for it
it will save time